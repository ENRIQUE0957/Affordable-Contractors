﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_Jobs_Cipriano
{
    class Program
    {
        static void Main(string[] args)
        {
            //creating object of Jclass
            Job job1 = new Job();
            job1.Description = "wash windows";
            job1.PerHourRate = 25.00;
            job1.TimeInHours = 3.5;//set time in hours
                                   //display job1 details
            Console.WriteLine("----------Job1 details-----------");
            Console.WriteLine("Description: " + job1.Description + ",Per Hours Rate: " + job1.PerHourRate + ", Time in Hours:" + job1.TimeInHours);
            Console.WriteLine("Total Fee : " + job1.totalFee);
            //creating object of Job class
            Job job2 = new Job();
            job2.Description = "wash cloths";
            job2.PerHourRate = 30.00;
            job2.TimeInHours = 1.5;//set time in hours
                                   //display job2 details
            Console.WriteLine("----------Job2 details-----------");
            Console.WriteLine("Description: " + job2.Description + ",Per Hours Rate: " + job2.PerHourRate + ", Time in Hours:" + job2.TimeInHours);
            Console.WriteLine("Total Fee : " + job2.totalFee);
            //creating another object of job class
            Job job3 = new Job();
            job3 = job1 + job2;
                               
            Console.WriteLine("----------Job3 details-----------");
            Console.WriteLine("Description: " + job3.Description + ",Per Hours Rate: " + job3.PerHourRate + ", Time in Hours:" + job3.TimeInHours);
            Console.WriteLine("Total Fee : " + (job1.totalFee + job2.totalFee));
            Console.ReadKey();

        }
    }
    //C# class
    class Job
    {
        //data fields
        private string description;
        private double timeInHours;
        private double perHourRate;
        public double totalFee;
        //getter and setter methods
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }
        public double PerHourRate
        {
            get { return this.perHourRate; }
            set
            {
                this.perHourRate = value;
                this.totalFee = this.perHourRate * timeInHours;
            }
        }
        public double TimeInHours
        {
            get { return this.timeInHours; }
            set
            {
                this.timeInHours = value;
                this.totalFee = this.perHourRate * timeInHours;
            }
        }
      
        public static Job operator +(Job j1, Job j2)
        {
            Job j3 = new Job();//creating Job class object
                               //description of two jobs
            j3.description = j1.description + " and " + j2.description;
            //sum of time in hours
            j3.timeInHours = j1.timeInHours + j2.timeInHours;
            
            j3.perHourRate = (j1.perHourRate + j2.perHourRate) / 2;
            return j3;
        }




    }
    }

