﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week_8_caseStudy
{
    class Program
    {
        static void Main(string[] args)
        {

            int contCurr;
            int contLast;
            Console.WriteLine("Please enter the number of contestants from last years contest");
            contLast = cont();
            Console.WriteLine("\nPlease enter the number of contestants from this years contest");
            contCurr = cont();
            array(contCurr);
            comp(contCurr, contLast);

        }

        public static int cont()
        {
            int last = 0;
            string b;
            b = (Console.ReadLine());
            int.TryParse(b, out last);
            while (last > 30 || last < 0)
            {
                Console.WriteLine("\nYou have entered and invalid response, please enter a valid number between 0 and 30.");
                b = (Console.ReadLine());
                int.TryParse(b, out last);
            }
            return last;
        }

        public static void array(int thisyear)
        {
            string[] contestant = new string[thisyear];
            string[] skill = new string[thisyear];
            for (int x = 0; x < thisyear; ++x)
            {
                Console.WriteLine("\nPlease enter contestant " + (x + 1) + "'s name");
                contestant[x] = Console.ReadLine();
                bool correct = false;
                while (!correct)
                {
                    Console.WriteLine("\nPlease enter contestant " + (x + 1) + " 's skill, 'S' for sing 'D' for dance 'M' for " +
                    "musical instrument 'O' for other");
                    string type = Console.ReadLine().ToUpper();

                    if (type == "S" || type == "D" || type == "M" || type == "O")
                    {
                        skill[x] = type;
                        correct = true;
                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter a valid parameter");
                    }
                }
            }
            talent(skill, contestant);
        }

        public static void talent(string[] skill, string[] contestant)
        {
            int dance = 0;
            int instrument = 0;
            int sing = 0;
            int other = 0;
            string entry;
            for (int x = 0; x < skill.Length; ++x)
            {

                if (skill[x] == "O")
                {
                    ++other;
                }
                else if (skill[x] == "S")
                {
                    ++sing;
                }
                else if (skill[x] == "D")
                {
                    ++dance;
                }
                else if (skill[x] == "M")
                {
                    ++instrument;
                }

            }
            Console.Clear();
            Console.WriteLine("There are:");
            Console.WriteLine("{0} dancers", dance);
            Console.WriteLine("{0} singers", sing);
            Console.WriteLine("{0} musicians", instrument);
            Console.WriteLine("{0} contestant(s) with other skills", other);
            Console.WriteLine("\nPlease enter a skill code 'S' 'D' 'M' 'O' to see a list of contestants with that skill or enter '!' to exit");
            entry = Console.ReadLine().ToUpper();
            while (entry != "!")
            {
                if (entry != "S" && entry != "D" && entry != "M" && entry != "O")
                {
                    Console.WriteLine("\nPlease try again: Enter a VALID skill code 'S' 'D' 'M' 'O' to see a list of contestants with that skill or '!' to exit");
                    entry = Console.ReadLine().ToUpper();
                    if (entry == "!")
                        break;
                }
                for (int x = 0; x < skill.Length; ++x)
                {
                    if (entry == skill[x])
                        Console.WriteLine(" Contestant " + contestant[x] + " skill " + skill[x]);
                }
                Console.WriteLine("\nPlease enter a skill code 'S' 'D' 'M' 'O' to see a list of contestants with that skill or enter '!' to exit");
                entry = Console.ReadLine().ToUpper();
            }
        }

        public static void comp(int contCurr, int contLast)
        {

            if (contCurr > contLast * 2)
            {
                Console.WriteLine("\nThe competition is more than twice as big this year!\n");
                Console.WriteLine("\nThe revenue expected for this year's competition is {0:C}", (contCurr * 25));
            }
            else

                 if (contCurr > contLast && contCurr <= (contLast * 2))
            {
                Console.WriteLine("\nThe competition is bigger than ever!\n");
                Console.WriteLine("\nThe revenue expected for this year's competition is {0:C}", (contCurr * 25));
            }
            else

                 if (contCurr < contLast)
            {
                Console.WriteLine("\nA tighter race this year! Come out and cast your vote!\n");
                Console.WriteLine("\nThe revenue expected for this year's competition is {0:C}", (contCurr * 25));
            }


        }
    }
}
