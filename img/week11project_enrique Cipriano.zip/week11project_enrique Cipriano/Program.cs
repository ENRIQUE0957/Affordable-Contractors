﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week11project_enrique_Cipriano
{
    class Program
    {
        static void Main(string[] args)
        {
            //creating array to store 10 double

            double[] arr = { 20.3, 44.6, 32.5, 46.7, 89.6, 67.5, 12.3, 14.6, 22.1, 13.6 };

            int sub; //to store subscript value as input

            do

            {

                Console.Write("Enter a subscript or 99 to quit: "); 

                sub = Convert.ToInt32(Console.ReadLine()); //input

                if (sub != 99) //if user does not want to quit

                {

                    try

                    {

                        //output

                        Console.WriteLine("Element at subscript {0} is {1}", sub, arr[sub]);

                    }

                    catch (IndexOutOfRangeException e)

                    {

                        //error message

                        Console.WriteLine("Index was outside the bounds of the array.");

                    }

                    Console.WriteLine();

                }

            } while (sub != 99); 

            Console.WriteLine("Thank you for using this application!"); //exit message

        }
    }
    }

