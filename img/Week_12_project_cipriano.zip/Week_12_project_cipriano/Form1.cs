﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_12_project_cipriano
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double i = 0;
            bool result = double.TryParse(textBox1.Text, out i); //i now = 108  
            if (result)
            {
                double res = i * 2.54;
                string str = res.ToString();
                label5.Text = str + " centimeters";
                label4.Text = "";
            }
            else
            {
                label4.Text = "ENTER VALID NUMBER";
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            double i = 0;
            bool result = double.TryParse(textBox1.Text, out i); //i now = 108  
            if (result)
            {


                label4.Text = "";
            }
            else
            {
                bool valid = label4.Text == "";
                if (valid)
                {
                    label4.Text = "";
                }
                else
                {
                    label4.Text = "ENTER VALID NUMBER";
                }

            }


        }

        private void label1_Click(object sender, EventArgs e)
        {


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = string.Empty;
            this.label4.Text = "";
            this.label5.Text = "";
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }




    }


    }




